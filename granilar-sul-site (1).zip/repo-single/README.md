# Site — Granilar Sul Marmoraria

Site institucional de uma página (landing page) da Granilar Sul Marmoraria, com foco em geração de leads via WhatsApp.

## Estrutura de arquivos

```
├── index.html      → página completa (logo, fotos e ícones já embutidos no próprio arquivo)
├── robots.txt       → instruções para os robôs do Google
├── sitemap.xml        → mapa do site para o Google Search Console
└── README.md          → este arquivo
```

✅ **`index.html` é 100% autossuficiente** — todas as imagens, a logo e os ícones estão embutidos dentro dele (por isso o arquivo é grande, ~3MB). Não existe pasta de imagens para se preocupar em manter junto.

> Nota técnica: por ser mais simples de publicar, optamos por deixar tudo em um único arquivo. O único efeito colateral é que o carregamento inicial da página fica um pouco mais lento do que se as imagens fossem arquivos separados (e o Google Imagens não indexa as fotos individualmente). Se no futuro quiser otimizar isso, é só pedir a versão com as imagens separadas.

## Como subir para o GitHub

1. Crie um repositório novo no GitHub (ex: `granilar-sul-site`), **sem** marcar a opção de criar README (para não dar conflito).
2. No seu computador, dentro desta pasta, rode:
   ```bash
   git init
   git add .
   git commit -m "Primeira versão do site"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/granilar-sul-site.git
   git push -u origin main
   ```
   (troque `SEU-USUARIO` e o nome do repositório pelos seus)

## Como publicar gratuitamente com GitHub Pages

1. No repositório, vá em **Settings → Pages**.
2. Em "Source", selecione a branch `main` e a pasta `/ (root)`.
3. Clique em **Save**.
4. Em alguns minutos, o site estará no ar em:
   `https://SEU-USUARIO.github.io/granilar-sul-site/`

### Se você tiver um domínio próprio (ex: granilarsul.com.br)

1. Ainda em **Settings → Pages**, no campo "Custom domain", digite seu domínio e salve.
2. No painel do seu provedor de domínio (Registro.br, Hostinger etc.), crie um registro **CNAME** apontando `www` para `SEU-USUARIO.github.io`, e registros **A** apontando o domínio raiz para os IPs do GitHub Pages:
   ```
   185.199.108.153
   185.199.109.153
   185.199.110.153
   185.199.111.153
   ```
3. Depois de propagado (pode levar até 24h), atualize os arquivos `robots.txt`, `sitemap.xml` e as tags `og:url` / `canonical` dentro do `index.html` para o seu domínio final.

## Antes de publicar, confira

- [ ] Número de WhatsApp e telefone estão corretos
- [ ] Endereço está correto
- [ ] Trocar `https://www.granilarsul.com.br/` (usado como placeholder no `sitemap.xml`, `robots.txt` e nas meta tags do `index.html`) pelo domínio real, se for diferente
- [ ] Depois de publicado, cadastrar o site no [Google Search Console](https://search.google.com/search-console) e enviar o `sitemap.xml`
